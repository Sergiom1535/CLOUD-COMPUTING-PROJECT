#-*- coding: utf-8 -*-

from bs4 import BeautifulSoup
import requests
import boto3
import re

def lambda_handler(event, context):
    
    # Connect to Website 
    URL = "http://52.53.164.186"
    page = requests.get(URL)
    soup = BeautifulSoup(page.content, 'html.parser')
    # Find the table where posts are stored 
    table = soup.find_all('tr')
    num_of_posts = len(table) - 1
    
    # Posting metric to Cloud Watch
    cloudwatch = boto3.client('cloudwatch')
    cloudwatch.put_metric_data(
        MetricData = [
            {
                'MetricName': 'Forum-Posts',
                'Dimensions': [
                    {
                        'Name': 'FORUM-SITE',
                        'Value': '0'
                    },
                    {
                        'Name': 'VERSION',
                        'Value': '1.0'
                    },
                ],
                'Unit': 'None',
                'Value': num_of_posts
            },
        ],
        Namespace = 'Webscraper-posts'
    )
    
    # Calling the put-metric method again for the second metric to be posted using this parsing method 
    # Creating the regex
    word_of_interest = re.compile('.*cloud.*', re.IGNORECASE)
    word_of_interest_count = Word_of_Interest(word_of_interest, table)
    cloudwatch.put_metric_data(
        MetricData = [
            {
                'MetricName': 'Forum-Posts',
                'Dimensions': [
                    {
                        'Name': 'FORUM-SITE',
                        'Value': '0'
                    },
                    {
                        'Name': 'VERSION',
                        'Value': '1.0'
                    },
                ],
                'Unit': 'None',
                'Value': word_of_interest_count
            },
        ],
        Namespace = 'Webscraper-word_of_interest'
    )
    
    return {
    'new' : word_of_interest_count,
    'statusCode': 200,
    'body': 'metric published'
    }

  
def Word_of_Interest(regex, html):
    counter = 0
    for element in html: 
        if regex.search(str(element)):  # If the word of interest is found increment counter
            counter += 1
    return counter
    

