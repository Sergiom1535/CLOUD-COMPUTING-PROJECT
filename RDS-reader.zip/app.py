import sys
import logging
import rds_config
import pymysql
import boto3
import botocore
import time


#rds settings
rds_host  = "testdb.ccvnbnct7vxa.us-west-1.rds.amazonaws.com"
name = rds_config.db_username
password = rds_config.db_password
db_name = rds_config.db_name



try:
    conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

#logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")

def lambda_handler(event, context):
    
    with conn.cursor() as cur:
        cur.execute("select * from posts")
        item_count = 0
        for row in cur:
            item_count += 1
    conn.commit()
    
    with conn.cursor() as curr:
        curr.execute("select post_owner from posts")
        ownerLists = []
        for row in curr:
            ownerLists.append(row)
        mostPosts = 0
        mostPostsOwner = ownerLists[0]
        for name in ownerLists:
            if ownerLists.count(name) > mostPosts:
                mostPosts = ownerLists.count(name)
                mostPostsOwner = name
                
        print(mostPosts)
        print(mostPostsOwner[0] )

    conn.commit()
    
    
    cloudwatch = boto3.client('cloudwatch')
    cloudwatch.put_metric_data(
        MetricData = [
            {
                'MetricName': 'Website-posts',
                'Dimensions': [
                    {
                        'Name': 'FORUM-SITE',
                        'Value': 'Post-count'
                    },
                    {
                        'Name': 'VERSION',
                        'Value': '1.0'
                    },
                ],
                'Unit': 'None',
                'Value': item_count
            },
        ],
        Namespace = 'Item-Count'
    )
    cloudwatch.put_metric_data(
        MetricData = [
            {
                'MetricName':  mostPostsOwner[0],
                'Dimensions': [
                    {
                        'Name': 'FORUM-SITE',
                        'Value': 'Post-Count-Name'
                    },
                    {
                        'Name': 'VERSION',
                        'Value': '1.0'
                    },
                ],
                'Unit': 'None',
                'Value': mostPosts
            },
        ],
        Namespace = 'Name-Top-Posts'
    )
    return {
    'statusCode': 200,
    'body': 'metric published'
    }
    
    #return "Added %d items from RDS MySQL table" %(item_count)